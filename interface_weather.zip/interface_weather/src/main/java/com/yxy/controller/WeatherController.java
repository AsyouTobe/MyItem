package com.yxy.controller;
 
import com.yxy.service.WeatherDateService;
import com.yxy.vo.WeatherResponse;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/weather")
public class WeatherController {
	@Autowired
	private WeatherDateService weatherDateService;

	@RequestMapping("/cityId/{cityId}")
	public WeatherResponse getReportByCityId(@PathVariable("cityId") String cityId) {
		return weatherDateService.getDateByCityId(cityId);

	}

	@RequestMapping("/cityName/{cityName}")
	public WeatherResponse getReportByCityName(@PathVariable("cityName") String cityName) {
		return weatherDateService.getDateByCityName(cityName);

	}
}