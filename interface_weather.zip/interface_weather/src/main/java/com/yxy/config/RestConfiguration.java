package com.yxy.config;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
/**
 * 配置类
 * @Description: TODO 
 * @ClassName: RestConfiguration
 * @author chengshengqing-YiAn  2019年2月28日 上午10:25:38
 * @see
 */
@Configuration
public class RestConfiguration {
 
	@Autowired
	private RestTemplateBuilder builder;
	@Bean
	public RestTemplate restTemplate(){
		return builder.build();
	}
	
	
}