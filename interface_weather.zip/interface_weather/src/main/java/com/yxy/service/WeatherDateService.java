package com.yxy.service;

import com.yxy.vo.WeatherResponse;

/**
 * 
 * @Description: 根据城市和城市ID查询天气的接口 
 * @ClassName: WeatherDateService

 */
public interface WeatherDateService {
 
	//根据城市id查询天气
	WeatherResponse getDateByCityId(String cityId);
	//根据城市名字查询天气
	WeatherResponse getDateByCityName(String cityName);
}