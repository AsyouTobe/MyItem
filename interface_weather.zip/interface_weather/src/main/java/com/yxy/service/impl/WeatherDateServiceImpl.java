package com.yxy.service.impl;
 
import java.io.IOException;
import com.yxy.service.WeatherDateService;
import com.yxy.vo.WeatherResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
 
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class WeatherDateServiceImpl implements WeatherDateService {
	
	
	
	@Autowired
	private RestTemplate restTemplate;
	private final String WEATHER_API="http://wthrcdn.etouch.cn/weather_mini";
    
	
	
	@Override
	public WeatherResponse getDateByCityId(String cityId) {
		
		String uri=WEATHER_API+"?citykey="+cityId;
		return this.doGetWeatherData(uri);
	}
 
	@Override
	public WeatherResponse getDateByCityName(String cityName) {
		String uri=WEATHER_API+"?city="+cityName;
		return this.doGetWeatherData(uri);
	}
 
	private WeatherResponse doGetWeatherData(String uri) {
		
		//模拟get请求
		//this.restTemplate.getForObject("请求路径"+"携带的参数",预期的返回类型[Object.class]);
		ResponseEntity<String> response=restTemplate.getForEntity(uri, String.class);

		 String strBody=null;
		 
		
		if(response.getStatusCodeValue()==200){
			strBody=response.getBody();
		}
		
		//jackson库中的类
		ObjectMapper mapper= new ObjectMapper();
		WeatherResponse weather=null;
		try {
			//mapper.readValue是将json结构转换成成java对象   
			//mapper.writeValue是将java对象转成json结构
			weather=mapper.readValue(strBody, WeatherResponse.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return weather;
	}
	
}