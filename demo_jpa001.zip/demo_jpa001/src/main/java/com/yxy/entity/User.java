package com.yxy.entity;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Proxy;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author 杨
 * @date $
 **/
@Data                    //Lombok的注解，自动注入@Getter和@Setter
@Entity                 //表明这是个实体类
@Proxy(lazy = false)    //关闭延迟加载，不然测试单元总是报错
@Table(name = "user")   //对应数据库中的表名，若是没加，则默认类名的小写
@Slf4j                  //打印日志
public class User implements Serializable {

    @Id                //整个和、SpringData Jpa必须加ID，否则会报错
    int id;
    private String username;
    private String password;
    private int	sex;
    private String phone;


}
