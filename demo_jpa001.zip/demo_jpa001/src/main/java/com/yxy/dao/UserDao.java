package com.yxy.dao;

import com.yxy.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

/**
 * @author 杨
 * @date 2019/04/13$
 **/
@Repository
public interface UserDao extends JpaRepository<User, Integer> , JpaSpecificationExecutor<User> {


    //自定义更新方法
    @Modifying
    @Transactional
    @Query(value = "update user a set a.username=:username,a.password=:password where a.id=:id",nativeQuery=true)
    public int updateUserById(@Param("id") Integer id, @Param("username") String username,@Param("password") String password);

}
