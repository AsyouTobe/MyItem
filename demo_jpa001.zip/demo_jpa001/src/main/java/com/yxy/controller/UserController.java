package com.yxy.controller;

import com.yxy.dao.UserDao;
import com.yxy.service.impl.UserServerImpl;
import com.yxy.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

/**
 * @author 杨
 * @date $
 **/

@RestController
@RequestMapping(value = "/")
public class UserController {
    @Autowired
    UserServerImpl userServer;

    @RequestMapping(value = "/")
public List<User> findAllUser() throws Exception {
        return userServer.findAll();
    }
    @RequestMapping(value = "/select/{id}")
    public  User findUserByName(@PathVariable Integer id) throws Exception {
        return userServer.findUserById(id);
    }
    @RequestMapping(value = "/insert/{username}/{password}")
    public  int insertUser(@PathVariable String username,@PathVariable String password) throws Exception {
         User  user=new User();
          user.setUsername(username);
          user.setPassword(password);
        return userServer.insertUser(user);
    }


    @RequestMapping(value = "/delete/{id}")
    public  int delUserById(@PathVariable Integer id) throws Exception {

        return userServer.delUserById(id);
    }


    @RequestMapping(value = "/update/{id}/{username}/{password}")
    public  int UpdateUserById(@PathVariable Integer id,@PathVariable String username,@PathVariable String password) throws Exception {
        User user=new User();
        user.setUsername(username);
        user.setPassword(password);
        return userServer.updateUserById(id,username,password);
    }

    @RequestMapping(value = "/update2/{id}/{username}/{password}/{sex}/{phone}")
    public  int UpdateUser(User user) throws Exception {

        return userServer.updateUser(user);
    }

}
