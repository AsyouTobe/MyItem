package com.yxy.service.impl;

import com.yxy.dao.UserDao;
import com.yxy.service.UserServer;
import com.yxy.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author 杨
 * @date $
 **/
@Slf4j
@Service(value = "UserServer")
public class UserServerImpl implements UserServer {
    @Autowired
    UserDao userDao;
    //继承JpaRepository里的方法
    @Override

    public List<User> findAll() throws Exception {
        return userDao.findAll();

    }
    //继承JpaRepository里的方法
    @Override
    public User findUserById(Integer id) throws Exception {
        Optional<User> user= userDao.findById(id);
            return user.get();

    }
    //继承JpaRepository里的方法
    @Override
    public int delUserById(Integer id) throws Exception {
        userDao.deleteById(id);
        return 0;
    }

    //继承JpaRepository里的方法
    @Override
    public int insertUser(User user) throws Exception {
        userDao.save(user);
        return 0;
    }
//继承JpaRepository里的方法
    @Override
    public int updateUser(User user) {
        userDao.saveAndFlush(user);
        return 0;
    }

    //自定义更新方法
    @Override
    public int updateUserById(Integer id,String username,String password) throws Exception {
        int result=userDao.updateUserById(id,username,password);
        log.debug("删除成功");
        return  0;
    }
}
