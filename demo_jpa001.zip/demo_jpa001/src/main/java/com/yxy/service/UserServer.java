package com.yxy.service;

import com.yxy.entity.User;

import java.util.List;
import java.util.Optional;

/**
 * @author 杨
 * @date $
 **/
public interface UserServer {
    public List<User> findAll()throws Exception;
    public User findUserById(Integer id)throws Exception;
    public int delUserById(Integer id)throws  Exception;
    //自定义更新方法
    public int updateUserById(Integer id,String username,String password)throws  Exception;;
    public int insertUser(User user)throws  Exception;;
    public int updateUser(User user);
}
