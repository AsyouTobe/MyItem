package music.constant;

public class Const {

}
