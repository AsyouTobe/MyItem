/**
  * Copyright 2018 bejson.com 
  */
package music.pass;

/**
 * Auto-generated: 2018-11-29 15:21:40
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Req {

    private Data data;
    private int code;
    public void setData(Data data) {
         this.data = data;
     }
     public Data getData() {
         return data;
     }

    public void setCode(int code) {
         this.code = code;
     }
     public int getCode() {
         return code;
     }

}