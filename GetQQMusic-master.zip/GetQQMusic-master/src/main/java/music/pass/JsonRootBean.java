/**
  * Copyright 2018 bejson.com 
  */
package music.pass;

/**
 * Auto-generated: 2018-11-29 15:21:40
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class JsonRootBean {

    private Req req;
    private Req_0 req_0;
    private int code;
    private long ts;
    public void setReq(Req req) {
         this.req = req;
     }
     public Req getReq() {
         return req;
     }

    public void setReq_0(Req_0 req_0) {
         this.req_0 = req_0;
     }
     public Req_0 getReq_0() {
         return req_0;
     }

    public void setCode(int code) {
         this.code = code;
     }
     public int getCode() {
         return code;
     }

    public void setTs(long ts) {
         this.ts = ts;
     }
     public long getTs() {
         return ts;
     }

}