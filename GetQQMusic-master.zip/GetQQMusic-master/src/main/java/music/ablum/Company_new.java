package music.ablum; /**
  * Copyright 2018 bejson.com 
  */

/**
 * Auto-generated: 2018-11-29 14:1:50
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Company_new {

    private String brief;
    private String headPic;
    private int id;
    private int is_show;
    private String name;

    public Company_new() {
    }

    public Company_new(String brief, String headPic, int id, int is_show, String name) {
        this.brief = brief;
        this.headPic = headPic;
        this.id = id;
        this.is_show = is_show;
        this.name = name;
    }

    public void setBrief(String brief) {
         this.brief = brief;
     }
     public String getBrief() {
         return brief;
     }

    public void setHeadPic(String headPic) {
         this.headPic = headPic;
     }
     public String getHeadPic() {
         return headPic;
     }

    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

    public void setIs_show(int is_show) {
         this.is_show = is_show;
     }
     public int getIs_show() {
         return is_show;
     }

    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

}